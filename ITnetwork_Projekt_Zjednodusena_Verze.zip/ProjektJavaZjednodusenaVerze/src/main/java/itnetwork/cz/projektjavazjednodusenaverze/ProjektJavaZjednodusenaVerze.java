/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package itnetwork.cz.projektjavazjednodusenaverze;

/**
 *
 * Main třída
 */
public class ProjektJavaZjednodusenaVerze {

    /**
     *
     * @param args
     */
    public static void main(String[] args) {
        //Přidání evidnční třídy
        Evidence evidence = new Evidence();
        //Spuštění programu
        evidence.programEvidence();
    }
}
